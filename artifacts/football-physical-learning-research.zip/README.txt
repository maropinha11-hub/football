Candidatos PPO reprovados para gameplay. Nenhum destes modelos e carregado pelo jogo.
Checkpoints de pesquisa do corpo nativo; carregue apenas com weights_only=True.
Reproducao e limites: docs/PESQUISA-CONTROLE-PROCEDURAL.md no repositorio.
