#include "animation_events.hpp"
#include "ball_anchor_741.hpp"
static_assert(sizeof(pes3_events::PhaseGate)==12,"phase gate ABI");
static_assert(sizeof(pes3_events::Anchor741)==12,"anchor 741 ABI");
extern "C" int owned_phase_gate(const pes3_events::PhaseGate* input,
    std::int32_t marker,unsigned chop,unsigned* output) {
  if(!input||!output||chop>1)return 0;
  try {
    const unsigned result=pes3_events::phase_gate(*input,marker,pes3_pose::BindArithmetic{bool(chop)});
    *output=result;return 1;
  }catch(const std::exception&){return 0;}
}
extern "C" int owned_anchor_741(float context,unsigned chop,pes3_events::Anchor741* output) {
  if(!output||chop>1)return 0;
  try {
    const auto result=pes3_events::anchor_741(context,pes3_pose::BindArithmetic{bool(chop)});
    *output=result;return 1;
  }catch(const std::exception&){return 0;}
}
