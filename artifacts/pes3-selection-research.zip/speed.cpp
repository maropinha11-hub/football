#include "locomotion_speed.hpp"
static_assert(sizeof(pes3_selection::SpeedInput)==20,"speed ABI mismatch");
extern "C" int step_speed(const pes3_selection::SpeedInput* input) {
  return pes3_selection::step_speed(*input);
}
