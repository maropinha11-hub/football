#include "locomotion_selection.hpp"
static_assert(sizeof(pes3_selection::Input)==44 && sizeof(pes3_selection::Decision)==32,"selection ABI mismatch");
extern "C" int select_locomotion(const pes3_selection::Input* input,pes3_selection::Decision* output) {
  if(!input || !output) return 0;
  return static_cast<int>(pes3_selection::select(*input,*output));
}
#include "locomotion_speed.hpp"
static_assert(sizeof(pes3_selection::SpeedInput)==20,"speed ABI mismatch");
extern "C" int step_speed(const pes3_selection::SpeedInput* input) {
  return pes3_selection::step_speed(*input);
}
