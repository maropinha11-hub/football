@echo off
setlocal
cd /d "%~dp0"
gameplayfootball.exe --config training.config --test-controller %*
if errorlevel 1 pause
