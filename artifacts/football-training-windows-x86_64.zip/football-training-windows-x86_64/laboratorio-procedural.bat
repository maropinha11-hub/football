@echo off
setlocal
cd /d "%~dp0"
gameplayfootball.exe --config training.config --procedural-lab --physical-rig %*
if errorlevel 1 pause
