@echo off
setlocal
cd /d "%~dp0"
gameplayfootball.exe --config training.config --player-match --physical-rig %*
if errorlevel 1 pause
