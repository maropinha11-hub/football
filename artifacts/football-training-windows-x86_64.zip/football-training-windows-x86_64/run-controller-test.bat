@echo off
setlocal
cd /d "%~dp0"
gameplayfootball.exe --test-controller %*
pause
