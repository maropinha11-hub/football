@echo off
setlocal
cd /d "%~dp0"
gameplayfootball.exe --config training.config --training %*
if errorlevel 1 pause
