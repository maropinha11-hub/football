@echo off
setlocal
cd /d "%~dp0"
if not exist "pes3\pes_animation_tracks.fpsa" (
  echo Animacoes PES3 ausentes nesta pasta. Execute importar-pes3.bat primeiro.
  pause
  exit /b 1
)
gameplayfootball.exe --config training.config --training --pes3-live %*
if errorlevel 1 pause
