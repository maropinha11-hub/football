@echo off
setlocal
cd /d "%~dp0"
gameplayfootball.exe --config training.config --training --pes3-preview %*
pause
