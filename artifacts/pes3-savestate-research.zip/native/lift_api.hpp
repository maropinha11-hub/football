#pragma once
#include <cstdint>
// Caller supplies mutable copies of 32 MiB EE RAM and 16 KiB scratchpad.
// Output status 0 means a modeled function call returned; no full-frame claim.
struct Pes3LiftResult {
  std::uint32_t status, pc, word, reserved;
  std::uint64_t instructions, trace_hash;
  std::uint64_t registers[32];
  std::uint32_t float_registers[32];
  char error[192];
};
extern "C" int pes3_run_lifted(std::uint8_t* ram, std::uint8_t* scratch,
  std::uint32_t entry, const std::uint64_t* args, std::uint32_t count,
  std::uint32_t budget, Pes3LiftResult* result);
