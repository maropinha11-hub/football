#include "pose_ops.hpp"
extern "C" int pose_op(unsigned op,const float* a,const float* b,float alpha,float* out) {
  if(!a || !b || !out) return 0;
  try {
    pes3_pose::Vector x{},y{};
    std::memcpy(x.data(),a,16); std::memcpy(y.data(),b,16);
    if(op==1) { const auto m=pes3_pose::matrix(x); std::memcpy(out,m.data(),64); }
    else {
      const auto v=op==0 ? pes3_pose::multiply(x,y) : op==2 ? pes3_pose::rotate(x,y) :
        op==3 ? pes3_pose::blend(x,y,alpha) : throw std::domain_error("unknown helper");
      std::memcpy(out,v.data(),16);
    }
    return 1;
  } catch(const std::exception&) { return 0; }
}
