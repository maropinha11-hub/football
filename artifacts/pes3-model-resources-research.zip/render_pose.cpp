#include "render_pose.hpp"
static_assert(sizeof(pes3_pose::RenderMatrices)==1216,"render matrix ABI");
extern "C" int owned_render_matrices(const float* m,const float* s,unsigned count,unsigned chop,float* out) {
  if(!m||!out||count>19||chop>1)return 0;
  try {
    pes3_pose::RenderMatrices matrices;pes3_pose::RenderScales scales;
    std::memcpy(matrices.data(),m,sizeof(matrices));
    if(s)std::memcpy(scales.data(),s,sizeof(scales));
    const auto result=pes3_pose::render_matrices(matrices,s?&scales:nullptr,count,pes3_pose::BindArithmetic{bool(chop)});
    std::memcpy(out,result.data(),sizeof(result));return 1;
  }catch(const std::exception&){return 0;}
}
extern "C" int owned_render_position(const float* p,unsigned chop,float* out) {
  if(!p||!out||chop>1)return 0;
  try {
    std::array<float,3> position;std::memcpy(position.data(),p,sizeof(position));
    const auto result=pes3_pose::render_position(position,pes3_pose::BindArithmetic{bool(chop)});
    std::memcpy(out,result.data(),sizeof(result));return 1;
  }catch(const std::exception&){return 0;}
}
