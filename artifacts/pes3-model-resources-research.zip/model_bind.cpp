#include "model_bind.hpp"
static_assert(sizeof(pes3_pose::ModelBind)==3968,"model bind ABI");
extern "C" int model_bind_profile(const float* m,const int* p,const int* pairs,unsigned chop,pes3_pose::ModelBind* out) {
  if(!m||!p||!pairs||!out||chop>1)return 0;
  try {
    std::array<pes3_pose::Matrix,19> matrices;
    std::array<std::int32_t,19> parents,mirror;
    std::memcpy(matrices.data(),m,sizeof(matrices));
    std::memcpy(parents.data(),p,sizeof(parents));std::memcpy(mirror.data(),pairs,sizeof(mirror));
    const auto result=pes3_pose::initialize_model(matrices,parents,mirror,pes3_pose::BindArithmetic{bool(chop)});
    *out=result;return 1;
  } catch(const std::exception&) {return 0;}
}
extern "C" int model_bind(const float* m,const int* p,const int* pairs,pes3_pose::ModelBind* out) {
  return model_bind_profile(m,p,pairs,0,out);
}
