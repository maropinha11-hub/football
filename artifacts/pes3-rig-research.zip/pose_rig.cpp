#include "pose_rig.hpp"
static_assert(sizeof(pes3_pose::Bone)==176 && sizeof(pes3_pose::Rig)==3360,"rig ABI mismatch");
extern "C" int rig_op(unsigned op,pes3_pose::Rig* rigs,unsigned d,unsigned a,unsigned b,float alpha,int all) {
  if(!rigs || d>=3 || a>=3 || b>=3 || (all!=0 && all!=1)) return 0;
  try {
    std::array<pes3_pose::Rig,3> work{}; std::memcpy(work.data(),rigs,sizeof(work));
    for(const auto& r:work) pes3_pose::validate(r);
    auto& r=work[d];
    switch(op) {
      case 0: pes3_pose::compose_matrices(r); break;
      case 1: pes3_pose::ensure_composed(r); break;
      case 2: pes3_pose::ensure_local(r); break;
      case 3: pes3_pose::mirror_raw(r); break;
      case 4: pes3_pose::apply_mirror(r); break;
      case 5: pes3_pose::mirror_gate(r); break;
      case 6: pes3_pose::materialize(r); break;
      case 7: pes3_pose::mix(r,work[a],work[b],alpha,bool(all)); break;
      default: return 0;
    }
    for(const auto& v:work) pes3_pose::validate(v);
    std::memcpy(rigs,work.data(),sizeof(work)); return 1;
  } catch(const std::exception&) { return 0; }
}
